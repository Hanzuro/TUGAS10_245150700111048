package DAY11.TUGAS10;

public class Main {
    public static void main(String[] args) {
        data.dataSource();
        data.separatorTim();
        data.separatorAtribut();
        
        Menu.menuUtama();
    }
}
